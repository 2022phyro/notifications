const grpc = require('@grpc/grpc-js')
const protoLoader = require('@grpc/proto-loader')
const loremIpsum = require('lorem-ipsum').loremIpsum
const PROTO_PATH = '../../src/gRPC/notification.proto'
const packageDefinition = protoLoader.loadSync(
  PROTO_PATH,
  {
    keepCase: true,
    longs: String,
    enums: String,
    defaults: true,
    oneofs: true
  })
function getRandomText () {
  return loremIpsum({
    count: 1,
    format: 'plain',
    units: 'sentences'
  })
}
// const app = {
//   _id: '65f82af5ffac2ba844579770',
//   name: 'poeticverse',
//   email: 'app@a.com',
//   secret: '$2a$10$496tX2NZ5'
// }
const protoDescriptor = grpc.loadPackageDefinition(packageDefinition)
const NotificationService = protoDescriptor.notification.NotificationService

const metadata = new grpc.Metadata()
metadata.add('authorization', '2dc679861ca1c7_abfbc9fa894fd63522c4b84159509bc64ab4d8533157a44289f14e33f2ae7953')
const client = new NotificationService('localhost:50051', grpc.credentials.createInsecure())
// eslint-disable-next-line no-undef
console.log('Started client')
const call = client.sendNotification(meta = metadata)

call.on('data', (response) => {
  console.log('Received response:', JSON.stringify(response))
})

call.on('end', () => {
  console.log('End of responses')
})
call.on('error', (err) => {
  console.log('Error', err.code, err.details)
})

for (let i = 0; i < 1; i++) {
  const msg = {
    payload: JSON.stringify({
      appId: '660849fec8c16a722ae61db0',
      userId: 'your-user-id'
    }),
    data: JSON.stringify({
      title: 'Sample title',
      body: getRandomText(),
      name: 'duplo',
      icon: 'https://th.bing.com/th/id/R.f87a0379b71dd4cb1e1a79a24c900b0c?rik=RAEwKEBWKjE4xw&pid=ImgRaw&r=0'

    })
  }
  call.write(msg)
}
// call.end()
