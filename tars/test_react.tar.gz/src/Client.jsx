const TestClient = () => {
    return (
        <div>
            <h1>Notifai Test Client (React)</h1>
            <p>Test system for explaining subscribing and unsubscribing to notifications via notifai</p>
            <p>Click the subscribe button to begin</p>
        </div>
    );
};

export default TestClient;